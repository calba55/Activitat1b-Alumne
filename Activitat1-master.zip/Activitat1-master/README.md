# Activitat1
Activitat 1 - CPSOC
